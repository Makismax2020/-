"""Simplify planar regions, export seven printable solids, and render preview."""
import json
import math
from pathlib import Path

import bpy
import bmesh
import numpy as np
from mathutils import Vector

root = Path(__file__).resolve().parent
output = root/'output'
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
geometry = np.load(output/'geometry.npz')
mesh = bpy.data.meshes.new('Rounded HYGIEIA solid mesh')
mesh.from_pydata(geometry['vertices'].tolist(),[],geometry['faces'].tolist())
mesh.update()
obj = bpy.data.objects.new('HYGIEIA rounded no base',mesh)
bpy.context.collection.objects.link(obj)
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
modifier = obj.modifiers.new('Simplify only flat regions','DECIMATE')
modifier.decimate_type = 'DISSOLVE'
modifier.angle_limit = 0.003
modifier.use_dissolve_boundaries = False
bpy.ops.object.modifier_apply(modifier=modifier.name)
bm = bmesh.new()
bm.from_mesh(obj.data)
bmesh.ops.triangulate(bm,faces=list(bm.faces))
assert all(e.is_manifold for e in bm.edges), 'Simplification opened the mesh'
bm.to_mesh(obj.data)
bm.free()
scene = bpy.context.scene
scene.unit_settings.system = 'METRIC'
scene.unit_settings.scale_length = 0.001
scene.unit_settings.length_unit = 'MILLIMETERS'
bpy.ops.wm.stl_export(filepath=str(output/'HYGIEIA_rounded_no_base_200mm.stl'),
                      export_selected_objects=True,use_scene_unit=False)

bpy.ops.object.mode_set(mode='EDIT')
bpy.ops.mesh.select_all(action='SELECT')
bpy.ops.mesh.separate(type='LOOSE')
bpy.ops.object.mode_set(mode='OBJECT')
objects = sorted([o for o in scene.objects if o.type=='MESH'],
                 key=lambda o:min(v.co.x for v in o.data.vertices))
assert len(objects)==7
stats=[]
for index,(character,letter) in enumerate(zip('HYGIEIA',objects),1):
    letter.name = f'{index:02d}_{character}'
    bpy.ops.object.select_all(action='DESELECT')
    letter.select_set(True)
    bpy.context.view_layer.objects.active = letter
    low = [min(v.co[k] for v in letter.data.vertices) for k in range(3)]
    letter.location = (-low[0],-low[1],0)
    bpy.ops.wm.stl_export(filepath=str(output/f'{index:02d}_{character}.stl'),
                          export_selected_objects=True,use_scene_unit=False)
    letter.location = (0,0,0)
    stats.append({'letter':character,'triangles':len(letter.data.polygons)})

material = bpy.data.materials.new('Gold; actual mesh carries the rounding')
material.use_nodes = True
material.diffuse_color = (0.72,0.40,0.055,1)
bsdf = material.node_tree.nodes.get('Principled BSDF')
bsdf.inputs['Base Color'].default_value = material.diffuse_color
bsdf.inputs['Metallic'].default_value = 0.75
bsdf.inputs['Roughness'].default_value = 0.27
for letter in objects:
    letter.data.materials.append(material)
    # Interpolated shading enhances only an already rounded geometric surface.
    for face in letter.data.polygons:
        face.use_smooth = face.normal.z > 0.02
scene.world.color = (0.16,0.16,0.16)
target = Vector((100,20,2))
for name,position,energy,size in [
    ('Key',(30,-60,140),180000,110),
    ('Fill',(160,100,100),70000,90),
    ('Rim',(80,20,100),100000,60),
]:
    data = bpy.data.lights.new(name,'AREA')
    data.energy = energy
    data.shape = 'DISK'
    data.size = size
    light = bpy.data.objects.new(name,data)
    scene.collection.objects.link(light)
    light.location = position
    light.rotation_euler = (target-light.location).to_track_quat('-Z','Y').to_euler()
camera_data = bpy.data.cameras.new('Camera')
camera = bpy.data.objects.new('Camera',camera_data)
scene.collection.objects.link(camera)
camera.location = (100,-95,180)
camera.rotation_euler = (target-camera.location).to_track_quat('-Z','Y').to_euler()
camera_data.type = 'ORTHO'
camera_data.ortho_scale = 213
scene.camera = camera
scene.render.engine = 'CYCLES'
scene.cycles.device = 'CPU'
scene.cycles.samples = 96
scene.cycles.use_denoising = False
scene.view_layers[0].cycles.use_denoising = False
scene.render.resolution_x = 1700
scene.render.resolution_y = 540
scene.render.resolution_percentage = 100
scene.render.image_settings.file_format = 'PNG'
scene.render.filepath = str(output/'HYGIEIA_rounded_preview.png')
bpy.ops.object.select_all(action='DESELECT')
for letter in objects:
    letter.select_set(True)
bpy.context.view_layer.objects.active = objects[0]
bpy.ops.wm.save_as_mainfile(filepath=str(output/'HYGIEIA_rounded.blend'))
bpy.ops.render.render(write_still=True)
print('FINISHED',json.dumps(stats))
