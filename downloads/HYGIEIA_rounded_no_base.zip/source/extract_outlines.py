"""Extract the same Blender glyph outlines as the original, without any base."""
import json
from pathlib import Path
import bpy
import bmesh

root = Path(__file__).resolve().parent
bpy.ops.object.select_all(action='SELECT')
bpy.ops.object.delete(use_global=False)
curve = bpy.data.curves.new('Original lettering outline', 'FONT')
curve.body = 'HYGIEIA'
curve.font = bpy.data.fonts.load('/usr/share/fonts/opentype/urw-base35/NimbusRoman-Bold.otf')
curve.size = 40
curve.extrude = 2
curve.bevel_depth = 0
curve.resolution_u = 16
obj = bpy.data.objects.new('Letters', curve)
bpy.context.collection.objects.link(obj)
obj.select_set(True)
bpy.context.view_layer.objects.active = obj
bpy.ops.object.convert(target='MESH')
bm = bmesh.new()
bm.from_mesh(obj.data)
bmesh.ops.remove_doubles(bm, verts=list(bm.verts), dist=0.00001)
bm.normal_update()
low = [min(v.co[k] for v in bm.verts) for k in range(3)]
high = [max(v.co[k] for v in bm.verts) for k in range(3)]
edges = [e for e in bm.edges if all(abs(v.co.z-low[2]) < 0.0001 for v in e.verts)
         and any(abs(f.normal.z) < 0.5 for f in e.link_faces)]
adjacency = {}
for edge in edges:
    a,b = edge.verts
    adjacency.setdefault(a, []).append(b)
    adjacency.setdefault(b, []).append(a)
assert all(len(neighbors) == 2 for neighbors in adjacency.values())
remaining = set(adjacency)
rings = []
while remaining:
    start = remaining.pop()
    ring, previous, current = [start], None, start
    while True:
        following = next(v for v in adjacency[current] if v != previous)
        if following == start:
            break
        ring.append(following)
        remaining.remove(following)
        previous,current = current,following
    rings.append([[(float(v.co.x)-low[0])*200/(high[0]-low[0]),
                   (float(v.co.y)-low[1])*40/(high[1]-low[1])] for v in ring])
(root/'outlines.json').write_text(json.dumps({'text':'HYGIEIA','width_mm':200,'height_mm':40,'rings':rings}))
print('Extracted outline rings:', len(rings))
bm.free()
