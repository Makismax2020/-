"""Build flat-backed independent letters with a real rolled upper surface.

The signed distance to the unchanged 2D glyph boundary determines a circular
upper profile. Isosurface extraction resolves narrow serifs without intersecting
bevel faces or allowing one tiny corner to disable rounding of the whole word.
"""
import argparse
import json
import struct
from pathlib import Path

import numpy as np
import shapely
import trimesh
from scipy.spatial import cKDTree
from shapely.geometry import GeometryCollection, Polygon
from skimage.measure import marching_cubes

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, default=root/'output')
parser.add_argument('--pitch', type=float, default=0.16)
args = parser.parse_args()
args.output.mkdir(parents=True, exist_ok=True)
outlines = json.loads((root/'outlines.json').read_text())
footprint = GeometryCollection()
for ring in outlines['rings']:
    polygon = Polygon(ring)
    assert polygon.is_valid
    footprint = footprint.symmetric_difference(polygon)
letters = sorted(list(footprint.geoms), key=lambda poly:poly.bounds[0])
assert len(letters) == 7, f'Expected seven separate letters; got {len(letters)}'

def export_stl(path, vertices, faces):
    triangles = vertices[faces].astype(np.float32)
    normals = np.cross(triangles[:,1]-triangles[:,0], triangles[:,2]-triangles[:,0])
    lengths = np.linalg.norm(normals, axis=1)
    assert np.all(lengths > 0), 'Degenerate isosurface triangle'
    normals /= lengths[:,None]
    records = np.zeros(len(faces), dtype=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attributes','<u2')]))
    records['normal'] = normals
    records['vertices'] = triangles
    with path.open('wb') as handle:
        handle.write(b'HYGIEIA rounded top; flat back; no plaque; units mm'.ljust(80,b' '))
        handle.write(struct.pack('<I',len(faces)))
        handle.write(records.tobytes())

all_vertices, all_faces, report = [], [], []
vertex_offset = 0
pitch = args.pitch
wall_height = 1.5
round_height = 3.5
round_width = 2.3
for index,(character,poly) in enumerate(zip(outlines['text'],letters),1):
    xmin,ymin,xmax,ymax = poly.bounds
    xs = np.arange(xmin-3.371*pitch,xmax+3*pitch,pitch)
    ys = np.arange(ymin-3.193*pitch,ymax+3*pitch,pitch)
    zs = np.arange(-2.5*pitch,5+3*pitch,pitch)
    xx,yy = np.meshgrid(xs,ys,indexing='ij')
    points = shapely.points(xx,yy)
    distances = shapely.distance(points,poly.boundary)
    shapely.prepare(poly)
    inside = shapely.contains_xy(poly,xx,yy)
    signed_distance = np.where(inside,distances,-distances)
    # Elliptical quarter arc: vertical at the edge and horizontal at its crown.
    inset = np.clip(distances/round_width,0,1)
    roof = wall_height+round_height*np.sqrt(np.maximum(0,1-(1-inset)**2))
    field = np.minimum(signed_distance[:,:,None],np.minimum(zs[None,None,:],roof[:,:,None]-zs[None,None,:])).astype(np.float32)
    vertices,faces,_,_ = marching_cubes(field,level=0,spacing=(pitch,pitch,pitch),
                                       gradient_direction='descent',allow_degenerate=False)
    vertices += np.array([xs[0],ys[0],zs[0]])
    # Collapse only microscopic sliver edges before binary STL quantization.
    vertices = vertices.astype(np.float32).astype(np.float64)
    parent = np.arange(len(vertices))
    def find(index):
        while parent[index] != index:
            parent[index] = parent[parent[index]]
            index = parent[index]
        return index
    for a,b in cKDTree(vertices).query_pairs(0.0001,output_type='ndarray'):
        parent[find(b)] = find(a)
    parent = np.array([find(i) for i in range(len(vertices))])
    faces = parent[faces]
    faces = faces[(faces[:,0]!=faces[:,1]) & (faces[:,1]!=faces[:,2]) & (faces[:,2]!=faces[:,0])]
    mesh = trimesh.Trimesh(vertices=vertices,faces=faces,process=False)
    mesh.merge_vertices(digits_vertex=5)
    mesh.update_faces(mesh.nondegenerate_faces(height=0.00000001))
    mesh.update_faces(mesh.unique_faces())
    mesh.remove_unreferenced_vertices()
    mesh.fix_normals()
    assert mesh.is_watertight and mesh.is_winding_consistent and mesh.volume > 0, (character,mesh.is_watertight,mesh.is_winding_consistent,mesh.volume)
    vertices,faces = mesh.vertices,mesh.faces
    triangles = vertices[faces]
    signed_volume = np.einsum('ij,ij->i',triangles[:,0],np.cross(triangles[:,1],triangles[:,2])).sum()/6
    if signed_volume < 0:
        faces = faces[:,[0,2,1]]
    export_stl(args.output/f'{index:02d}_{character}.stl',vertices-np.array([xmin,ymin,0]),faces)
    all_vertices.append(vertices)
    all_faces.append(faces+vertex_offset)
    vertex_offset += len(vertices)
    zlevels = len(np.unique(np.round(vertices[:,2],3)))
    assert zlevels > 30, 'Rounded top has disappeared'
    stats = {'letter':character,'file':f'{index:02d}_{character}.stl','triangles':len(faces),
             'z_levels':zlevels,'max_height_mm':float(vertices[:,2].max()),'rounded_top':True}
    report.append(stats)
    print(json.dumps(stats),flush=True)
vertices = np.concatenate(all_vertices)
faces = np.concatenate(all_faces)
export_stl(args.output/'HYGIEIA_rounded_no_base_200mm.stl',vertices,faces)
dimensions = vertices.max(axis=0)-vertices.min(axis=0)
assert abs(dimensions[0]-200)<0.15 and abs(dimensions[1]-40)<0.15
np.savez_compressed(args.output/'geometry.npz',vertices=vertices,faces=faces)
(args.output/'validation.json').write_text(json.dumps({'text':outlines['text'],'dimensions_mm':dimensions.tolist(),
  'base':False,'components_expected':7,'wall_height_mm':wall_height,'rounded_height_mm':round_height,
  'round_width_mm':round_width,'sampling_mm':pitch,'letters':report},indent=2))
print('TOTAL',len(faces),'triangles; dimensions',dimensions.tolist(),flush=True)
