"""Validate final binary STL files and measure the actual curved upper surface."""
import argparse
import json
import struct
from pathlib import Path

import numpy as np
import trimesh

parser = argparse.ArgumentParser()
parser.add_argument('directory',type=Path)
args = parser.parse_args()
files = sorted(args.directory.glob('0?_*.stl'))+[args.directory/'HYGIEIA_rounded_no_base_200mm.stl']
assert len(files)==8
results=[]
for path in files:
    data=path.read_bytes()
    count=struct.unpack_from('<I',data,80)[0]
    assert len(data)==84+count*50
    records=np.frombuffer(data,offset=84,dtype=np.dtype([('normal','<f4',(3,)),('vertices','<f4',(3,3)),('attributes','<u2')]))
    triangles=records['vertices'].astype(np.float64)
    assert np.all(np.isfinite(triangles))
    coordinates=np.rint(triangles.reshape((-1,3))*1e5).astype(np.int64)
    _,indices=np.unique(coordinates,axis=0,return_inverse=True)
    faces=indices.reshape((-1,3))
    assert np.all((faces[:,0]!=faces[:,1]) & (faces[:,1]!=faces[:,2]) & (faces[:,2]!=faces[:,0])), (path,'collapsed triangle')
    cross=np.cross(triangles[:,1]-triangles[:,0],triangles[:,2]-triangles[:,0])
    areas=np.linalg.norm(cross,axis=1)/2
    assert np.all(areas>1e-10),(path,'zero area triangle')
    assert len(np.unique(np.sort(faces,axis=1),axis=0))==count,(path,'duplicate facets')
    edges=np.concatenate([faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]])
    edges.sort(axis=1)
    _,edge_counts=np.unique(edges,axis=0,return_counts=True)
    assert np.all(edge_counts==2),(path,'open or nonmanifold edge')
    mesh=trimesh.load_mesh(path,process=True)
    assert mesh.is_watertight and mesh.is_winding_consistent
    components=mesh.split(only_watertight=False)
    expected=7 if path.name.startswith('HYGIEIA') else 1
    assert len(components)==expected,(path,len(components),expected)
    assert all(c.volume>0 for c in components)
    assert abs(triangles[:,:,2].min())<0.001
    normals=cross/(2*areas[:,None])
    centers=triangles.mean(axis=1)
    upper=normals[:,2]>0.01
    curved=upper & (normals[:,2]<0.99) & (centers[:,2]>1.45)
    curved_fraction=float(areas[curved].sum()/areas[upper].sum())
    assert curved_fraction>0.65,(path,'upper surface is too flat',curved_fraction)
    assert np.ptp(triangles[:,:,2])>=4.9
    stats={'file':path.name,'triangles':count,'closed':True,'components':len(components),
           'dimensions_mm':np.round(mesh.extents,3).tolist(),
           'curved_top_area_fraction':round(curved_fraction,4),'flat_back_z_mm':0,
           'volume_mm3':round(float(mesh.volume),3)}
    results.append(stats)
    print(json.dumps(stats),flush=True)
combined=results[-1]
assert abs(combined['dimensions_mm'][0]-200)<0.15
assert abs(combined['dimensions_mm'][1]-40)<0.15
(args.directory/'final_validation.json').write_text(json.dumps(results,indent=2))
